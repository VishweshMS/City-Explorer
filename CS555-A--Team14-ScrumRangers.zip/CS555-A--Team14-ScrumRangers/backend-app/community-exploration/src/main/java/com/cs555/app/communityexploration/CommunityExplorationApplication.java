package com.cs555.app.communityexploration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunityExplorationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunityExplorationApplication.class, args);
	}
}
