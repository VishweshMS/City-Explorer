export const Colors = {
  primary100: 'white',
  primary500: 'black',
  primary800: 'EDD6DB',
  error100: 'grey',
  error500: 'red',
}