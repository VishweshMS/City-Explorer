package com.cs555.app.communityexploration.constant;

/**
 * @author Himanshu Dagar
 *
 */
public class CommunityExplorationConstant implements UrlConstants {

	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";

}
