INSERT INTO Video (userId, location, description, video_url, likes)
VALUES
(1, "New York", "Parallel Park Experience", "https://www.youtube.com/shorts/kzMwsiaWHcg", 10),
(2, "Hoboken", "Ann's Italian Festival", "https://www.youtube.com/shorts/CjsKlxPr9vE", 100),
(3, "Hoboken", "HOBOKEN vs JERSEY CITY", "https://www.youtube.com/shorts/USgQOei2PIg", 200),
(4, "Hoboken", "The Secret Of The Impossible Stick Challenge", "https://www.youtube.com/shorts/8Zs7ReAEYUU", 50),
(5, "New York", "Capturing unique perspective in Time Square New York", "https://www.youtube.com/shorts/6S6Rr8hqwJM", 70);
